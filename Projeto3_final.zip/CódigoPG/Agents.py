from pacman import *
from game import Agent, Directions
from util import Point, BFS

class DirectionValue():
    def __init__(self, direction, value):
        self.direction = direction
        self.value = value

class DumbAgent(Agent):
    def __init__(self, arvore_decisoes):
        self.move_function = arvore_decisoes
        
    def getAction(self, state):
        actualAction = self.evaluateTrees(state)
    
        if (actualAction not in state.getLegalPacmanActions()):
            actualAction = Directions.STOP

        return actualAction
    
    def evaluateTrees(self, state):
        north_value = DirectionValue("North", -1)
        south_value = DirectionValue("South", -1)
        east_value = DirectionValue("East", -1)
        west_value = DirectionValue("West", -1)
        stop_value = DirectionValue("Stop", -1)
        dir_values = [north_value, south_value, east_value, west_value, stop_value]

        if (Directions.NORTH in state.getLegalPacmanActions()):
            x = distToNextGhost(state, Directions.NORTH)
            y = distToNextFoodPill(state, Directions.NORTH)
            w = distToNextEdibleGhost(state, Directions.NORTH)
            z = distToNextPowerPill(state, Directions.NORTH)
            k = distBetweenClosestGhostAndClosestPowerPill(state, Directions.NORTH)
            north_value.value = self.move_function(x, y, w, z, k)
        
        if (Directions.SOUTH in state.getLegalPacmanActions()):
            x = distToNextGhost(state, Directions.SOUTH)
            y = distToNextFoodPill(state, Directions.SOUTH)
            w = distToNextEdibleGhost(state, Directions.SOUTH)
            z = distToNextPowerPill(state, Directions.SOUTH)
            k = distBetweenClosestGhostAndClosestPowerPill(state, Directions.SOUTH)
            south_value.value = self.move_function(x, y, w, z, k)
        
        if (Directions.WEST in state.getLegalPacmanActions()):
            x = distToNextGhost(state, Directions.WEST)
            y = distToNextFoodPill(state, Directions.WEST)
            w = distToNextEdibleGhost(state, Directions.WEST)
            z = distToNextPowerPill(state, Directions.WEST)
            k = distBetweenClosestGhostAndClosestPowerPill(state, Directions.WEST)
            west_value.value = self.move_function(x, y, w, z, k)
        
        if (Directions.EAST in state.getLegalPacmanActions()):
            x = distToNextGhost(state, Directions.EAST)
            y = distToNextFoodPill(state, Directions.EAST)
            w = distToNextEdibleGhost(state, Directions.EAST)
            z = distToNextPowerPill(state, Directions.EAST)
            k = distBetweenClosestGhostAndClosestPowerPill(state, Directions.EAST)
            east_value.value = self.move_function(x, y, w, z, k)
        
        x = distToNextGhost(state, Directions.STOP)
        y = distToNextFoodPill(state, Directions.STOP)
        w = distToNextEdibleGhost(state, Directions.STOP)
        z = distToNextPowerPill(state, Directions.STOP)
        k = distBetweenClosestGhostAndClosestPowerPill(state, Directions.STOP)
        stop_value.value = self.move_function(x, y, w, z, k)
        
        best_direction = dir_values[0]
        for dir in dir_values:
            if (dir.value >= best_direction.value):
                best_direction = dir
        return best_direction.direction


def distBetweenClosestGhostAndClosestPowerPill(state, direction):
    if direction not in state.getLegalPacmanActions():
        return -1
    dist_next_ghost = distToNextGhost(state, direction)
    dist_next_power_pill = distToNextPowerPill(state, direction)
    return dist_next_ghost - dist_next_power_pill

def distToNextGhost(state, direction):
    if direction not in state.getLegalPacmanActions():
        return -1
 
    successorState = state.generateSuccessor(0, direction)
 
    ghostStates = successorState.getGhostStates()
    nonEdibleGhostDistances = []
    pacmanPosition = successorState.getPacmanPosition()
    wallGrid = successorState.getWalls().data
 
    for ghostState in ghostStates:
        if ghostState.scaredTimer <= 0:
            position = ghostState.getPosition()
            pacmanPoint = Point(pacmanPosition[0], pacmanPosition[1])
            ghostPoint = Point(int(position[0]), int(position[1]))
            nonEdibleGhostDistances.append(BFS(wallGrid, pacmanPoint, ghostPoint))
 
    return min(nonEdibleGhostDistances) if len(nonEdibleGhostDistances) > 0 else -1
 
 
def distToNextEdibleGhost(state, direction):
    if direction not in state.getLegalPacmanActions():
        return -1
 
    successorState = state.generateSuccessor(0, direction)
 
    ghostStates = successorState.getGhostStates()
    edibleGhostDistances = []
    pacmanPosition = successorState.getPacmanPosition()
    wallGrid = successorState.getWalls().data
 
    for ghostState in ghostStates:
        if ghostState.scaredTimer > 0:
            position = ghostState.getPosition()
            pacmanPoint = Point(pacmanPosition[0], pacmanPosition[1])
            ghostPoint = Point(int(position[0]), int(position[1]))
            edibleGhostDistances.append(BFS(wallGrid, pacmanPoint, ghostPoint))
 
    return min(edibleGhostDistances) if len(edibleGhostDistances) > 0 else -1
 
def distToNextPowerPill(state, direction):
    if direction not in state.getLegalPacmanActions():
        return -1
 
    successorState = state.generateSuccessor(0, direction)
 
    capsuleDistances = []
    pacmanPosition = successorState.getPacmanPosition()
    wallGrid = successorState.getWalls().data
 
    for capsulePosition in successorState.getCapsules():
            pacmanPoint = Point(pacmanPosition[0], pacmanPosition[1])
            capsulePoint = Point(int(capsulePosition[0]), int(capsulePosition[1]))
            capsuleDistances.append(BFS(wallGrid, pacmanPoint, capsulePoint))
 
    return min(capsuleDistances) if len(capsuleDistances) > 0 else -1
 
def distToNextFoodPill(state, direction):
    if direction not in state.getLegalPacmanActions():
        return -1
 
    successorState = state.generateSuccessor(0, direction)
 
    foodDistances = []
    pacmanPosition = successorState.getPacmanPosition()
    wallGrid = successorState.getWalls().data
 
    for foodPosition in successorState.getFood().asList():
            pacmanPoint = Point(pacmanPosition[0], pacmanPosition[1])
            foodPoint = Point(int(foodPosition[0]), int(foodPosition[1]))
            foodDistances.append(BFS(wallGrid, pacmanPoint, foodPoint))
 
    return min(foodDistances) if len(foodDistances) > 0 else -1    