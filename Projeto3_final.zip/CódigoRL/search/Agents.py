from game import Agent
from game import Directions

class DumbAgent(Agent):
    def __init__(self):
        self.initial_state = None
        self.count = 0

    def getAction(self,state):
        if self.count == 0:
            self.initial_state = state
        self.count += 1
        if Directions.WEST in state.getLegalPacmanActions():
            return Directions.WEST
        else:
            return Directions.STOP

    def get_initial_state(self):
        return self.initial_state
