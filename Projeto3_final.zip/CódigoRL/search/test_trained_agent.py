from projeto3 import *
from myEnv import CustomEnvironment, CustomEnvironment2, CustomEnvironment3, CustomEnvironment4
from tensorforce.environments import Environment
from tensorforce.agents import Agent


args = readCommand("-l originalClassic".split())
environment = CustomEnvironment2()
agent = Agent.load(directory = os.getcwd()+'/original_position', filename = 'agent-3001-7', environment = environment,
    agent = 'dqn',
    network= dict(type = 'custom',
                        layers = [ [
                            dict(type='retrieve', tensors=['positions']),
                            dict(type = 'flatten'),
                            dict(type='dense', size=16),
                            dict(type='register', tensor='pos-embedding')
                    ],
                    [
                            dict(type='retrieve', tensors=['booleans']),
                            dict(type='embedding', size=16),
                            dict(type = 'flatten'),
                            dict(type='register', tensor='bool-embedding')
                    ],[
                            dict(type='retrieve', aggregation='concat',tensors=['pos-embedding', 'bool-embedding']),
                            dict(type='dense', size=16)
                     ]
                    ]),
    memory = 10000,
    # Optimization
    batch_size=10, learning_rate=0.001,
    #  subsampling_fraction=0.1,
    # multi_step=30,
    # Reward estimation
    # likelihood_ratio_clipping=0.1,
    discount=0.97, predict_terminal_values=True,
    # Critic
    # baseline='auto',
    # baseline_optimizer=dict(optimizer='adam', multi_step=10, learning_rate=0.001),
    # Preprocessing

    # Exploration
    exploration=0.00,
    variable_noise=0.0
    )
#agent = Agent.load('/home/guilherme/Unicamp/MachineLearning/Projeto3/BonsResultados', filename = 'agent-227151-14')
print(agent.get_specification())

run_train(environment, agent, 10, 10, 500, True, save_folder = 'savings_08jul', args = args)
