from pacman import *
from game import *
from layout import *
import numpy as np
import gym
from gym import spaces

def createGame(layout, pacman, ghosts, display, numGames, record, numTraining = 0, catchExceptions=False, timeout=30 ):
    rules = ClassicGameRules(timeout)
    beQuiet = False
    return rules.newGame(layout, pacman, ghosts, display, beQuiet, catchExceptions)

args = readCommand("-l smallClassic".split())
game = createGame(**args)
game.run()
print("depois")
