from pacman import *
from game import *
from layout import *
import numpy as np
from tensorforce.environments import Environment
from tensorforce.agents import Agent
from Agents import DumbAgent
from myAgent import MyPacman
import networkx as nx
import matplotlib.pyplot as plt
import math

class CustomEnvironment2(Environment):
    def __init__(self, initial_state):
        super().__init__()
        self.last_state = None
        self.initial_state = initial_state
        self.grid_width = self.initial_state.data.layout.width
        self.grid_height = self.initial_state.data.layout.height
        self.walls = self.initial_state.getWalls()
        self.initial_channel = self.build_channels(self.initial_state)


    def states(self):
        return {
        # there are 6 channels, where each channel represents: walls, foods, pacman, capsules, active ghosts and scared ghosts
        # each channel has 0 representing a void and 1 if the element exists in the given position
        # there is also a copy of each position channel representing the last state
        'walls': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'foods': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'capsules': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'pacman': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'last_pacman': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'active_ghosts': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'last_active_ghosts': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'scared_ghosts': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1),
        'last_scared_ghosts': dict(type = 'float', shape = (self.grid_width,self.grid_height), min_value = 0, max_value = 1)
        }

    def actions(self):
        return dict(type='int', num_values=5)

    def reset(self):

        channels = self.build_channels(self.initial_state)
        initial_state = dict({
            'walls': channels['walls'],
            'foods':channels['foods'],
            'capsules': channels['capsules'],
            'pacman': channels['pacman'],
            'last_pacman': channels['pacman'],
            'active_ghosts': channels['active_ghosts'],
            'last_active_ghotst': channels['active_ghosts'],
            'scared_ghosts': channels['scared_ghosts'],
            'last_scared_ghosts': channels['scared_ghosts']
        })

        self.last_state = initial_state

        return initial_state

    def direction_to_int(self, direction):
        if direction == 'North':
            int_direction = 0
        elif direction == 'South':
            int_direction = 1
        elif direction == 'East':
            int_direction = 2
        elif direction == 'West':
            int_direction = 3
        elif direction == 'Stop':
            int_direction = 4
        return int_direction

    def convert_action_to_number(self, action):
        if action == Directions.NORTH:
            action_number = 0
        elif action == Directions.SOUTH:
            action_number = 1
        elif action == Directions.EAST:
            action_number = 2
        elif action == Directions.WEST:
            action_number = 3
        elif action == Directions.STOP:
            action_number = 4

        return action_number

    def number_to_action(self, action_number):
        if action_number == 0:
            action = Directions.NORTH
        elif action_number == 1:
            action = Directions.SOUTH
        elif action_number == 2:
            action = Directions.EAST
        elif action_number == 3:
            action = Directions.WEST
        elif action_number == 4:
            action = Directions.STOP

        return action

    def build_channels(self, state):

        channels = {}

        # build the walls and food
        channels['walls'] = np.zeros((self.grid_width, self.grid_height))
        channels['foods'] = np.zeros((self.grid_width, self.grid_height))
        for i in range(0,self.grid_width):
            for j in range(0,self.grid_height):
                if self.walls[i][j] == True:
                    channels['walls'][i,j] = 1
                if state.hasFood(i,j) == True:
                    channels['foods'][i,j] = 1

        # build pacman position
        channels['pacman'] = np.zeros((self.grid_width, self.grid_height))
        tmp_pos = state.getPacmanPosition()
        i = tmp_pos[0]
        j = tmp_pos[1]
        channels['pacman'][i,j] = 1

        # build capsules position
        channels['capsules'] = np.zeros((self.grid_width, self.grid_height))
        tmp_pos = state.getCapsules()
        for pos in tmp_pos:
            i = pos[0]
            j = pos[1]
            channels['capsules'][i,j] = 1

        # build ghost postions
        channels['active_ghosts'] = np.zeros((self.grid_width, self.grid_height))
        channels['scared_ghosts'] = np.zeros((self.grid_width, self.grid_height))
        for ghost_state in state.getGhostStates():
            pos = ghost_state.getPosition()
            # ceil because ghost positions may be a float sometimes
            i = math.ceil(pos[0])
            j = math.ceil(pos[1])
            if (ghost_state.scaredTimer == 0):
                channels['active_ghosts'][i,j] = 1
            else:
                # the ghost is scared
                channels['scared_ghosts'][i,j] = 1

        return channels

    def build_state(self, state, previous_built_state):

        channels = self.build_channels(state)

        built_state = dict({
            'walls': channels['walls'],
            'foods':channels['foods'],
            'capsules': channels['capsules'],
            'pacman': channels['pacman'],
            'last_pacman': previous_built_state['pacman'],
            'active_ghosts': channels['active_ghosts'],
            'last_active_ghosts': previous_built_state['active_ghosts'],
            'scared_ghosts': channels['scared_ghosts'],
            'last_scared_ghosts': previous_built_state['scared_ghosts']
        })

        return built_state

    def next_state(self, actual_state, action):
        valid_action = action
        if action not in actual_state.getLegalPacmanActions():
            valid_action = Directions.STOP
        next_game_state = actual_state.generatePacmanSuccessor(valid_action)
        return self.build_state(next_game_state, self.last_state)

    def reward_function(self, state, action):
        valid_action = action
        # Agent also gets a bad reward if it selected a non valid action
        if action not in state.getLegalPacmanActions():
            legal_action_reward = -5
            valid_action = Directions.STOP
        else:
            legal_action_reward = 0

        next_game_state = state.generatePacmanSuccessor(valid_action)

        # Scored obtained by action
        if next_game_state.getNumFood() < state.getNumFood():
            # ate one food
            score_gain = 1
        elif len(next_game_state.getCapsules()) < len(state.getCapsules()):
            # ate a capsule
            score_gain = 20
        else:
            # didn't eat anything
            score_gain = -1

        if (next_game_state.getNumAgents() < state.getNumAgents()):
            # ate a ghost
            eat_ghost_reward = 20
        else:
            eat_ghost_reward = 0

        # Reward also depends on winning or not the game
        if next_game_state.isWin():
            win_lose_reward = 100
        elif next_game_state.isLose():
            win_lose_reward = -100
        else:
            win_lose_reward = 0


        #print('reward: ', score_gain + win_lose_reward + legal_action_reward+eat_ghost_reward, f'score gain = {score_gain}, win_lose_reward = {win_lose_reward}, legal_action_reward = {legal_action_reward}, eat ghost reward = {eat_ghost_reward}')
        # Total reward is composed of the score gained, the win/lose state and wheter the action chosen is valid or not
        return score_gain + win_lose_reward + legal_action_reward + eat_ghost_reward

    # Return True if the action is going to finish the game and False otherwhise
    def is_terminal(self, state, action):
        valid_action = action
        if action not in state.getLegalPacmanActions():
            valid_action = Directions.STOP
        next_game_state = state.generatePacmanSuccessor(valid_action)
        terminal  = False
        if next_game_state.isWin() == True or next_game_state.isLose() == True:
            terminal = True
        return terminal

    def execute(self, actions, state):
        self.last_state = self.build_state(state,self.last_state)
        next_state = self.next_state(state,actions)
        terminal = self.is_terminal(state, actions)
        reward = self.reward_function(state,actions)
        return next_state, terminal, reward

class CustomEnvironment(Environment):
    def __init__(self):
        super().__init__()
        self.last_state = self.reset()
        self.graph = None

    def states(self):
        return {
        'positions':dict(type='float',shape=(7,2), min_value = -1, max_value = 40),
        'booleans': dict(type = 'bool', shape = (8,))
        }


    def actions(self):
        return dict(type='int', num_values=5)

    def reset(self):

        agent_position = [(9,1),(9,1)]

        valid_actions = [False,False,True,True,True]

        agent_direction = self.direction_to_int('East')

        closest_ghost_pos =  [(8, 5),(8, 5)]
        closest_ghost_dir = 4
        closest_ghost_scared_timer = 0
        there_are_ghosts = True
        closest_capsule_position = [(3, 3)]
        there_are_capsules = True
        closest_food_pos = (0,0)
        ghost_away_food_nearby = (True)
        #previous_agent_position = (9,1)
        #previous_closest_ghost_pos = (8, 5)
        initial_state = dict({
            'positions' : agent_position + closest_ghost_pos + [closest_capsule_position] + [closest_food_pos] + [(closest_ghost_scared_timer,0)],
            'booleans' : valid_actions + [there_are_ghosts] + [there_are_capsules] + [ghost_away_food_nearby]
        })

        return initial_state

    def direction_to_int(self, direction):
        if direction == 'North':
            int_direction = 0
        elif direction == 'South':
            int_direction = 1
        elif direction == 'East':
            int_direction = 2
        elif direction == 'West':
            int_direction = 3
        elif direction == 'Stop':
            int_direction = 4
        return int_direction

    def convert_action_to_number(self, action):
        if action == Directions.NORTH:
            action_number = 0
        elif action == Directions.SOUTH:
            action_number = 1
        elif action == Directions.EAST:
            action_number = 2
        elif action == Directions.WEST:
            action_number = 3
        elif action == Directions.STOP:
            action_number = 4

        return action_number

    def number_to_action(self, action_number):
        if action_number == 0:
            action = Directions.NORTH
        elif action_number == 1:
            action = Directions.SOUTH
        elif action_number == 2:
            action = Directions.EAST
        elif action_number == 3:
            action = Directions.WEST
        elif action_number == 4:
            action = Directions.STOP

        return action

    def valid_actions_vector(self, state):
        output_vector = []
        for i in range(5):
            if self.number_to_action(i) in state.getLegalPacmanActions():
                output_vector.append(True)
            else:
                output_vector.append(False)

        return output_vector

    def closest_food(self, state):
        pacman_pos = state.getPacmanPosition()
        height = state.data.layout.height
        width = state.data.layout.width
        min_dist = 1000
        (x,y) = (-1,-1)
        for i in range(0,width):
            for j in range(0,height):
                if state.hasFood(i,j):
                    if self.min_distance(pacman_pos,(i,j)) < min_dist:
                        min_dist = self.min_distance(pacman_pos,(i,j))
                        x = i
                        y = j


        return (x,y)
    def closest_ghost_pos_scared_time(self,state):
        pacman_pos = state.getPacmanPosition()
        min_dist = 1000

        # check if there are ghosts
        if len(state.getGhostStates()) > 0:
            there_are_ghosts = True
        else:
            there_are_ghosts = False

        for ghost_state in state.getGhostStates():
            if self.min_distance(pacman_pos, ghost_state.getPosition()) < min_dist:
                min_dist = self.min_distance(pacman_pos, ghost_state.getPosition())
                closest_pos = ghost_state.getPosition()
                closest_dir = ghost_state.getDirection()
                scared_timer = ghost_state.scaredTimer
        if min_dist == 1000:
            # there are no ghosts
            closest_pos = (8,5)
            closest_dir = Directions.STOP
            scared_timer = 0
        return closest_pos,scared_timer, there_are_ghosts

    def closest_ghost_is_nearby(self, state, closest_pos, min_distance):
        if (self.min_distance(state.getPacmanPosition(), closest_pos) <= min_distance):
            return True
        else:
            return False

    def there_is_food_nearby(self, state, closest_food, min_distance):
        if (self.min_distance(state.getPacmanPosition(), closest_food) <= min_distance):
            return True
        else:
            return False

    def closest_capsule_position(self,state):
        pacman_pos = state.getPacmanPosition()
        tmp_pos = state.getCapsules()
        if len(tmp_pos) != 0:
            min_dist = 1000
            for pos in tmp_pos:
                if self.min_distance(pacman_pos,pos) < min_dist:
                    min_dist = self.min_distance(pacman_pos,pos)
                    pos_closest_capsule = pos
        else:
            pos_closest_capsule = (-1,-1)
        return pos_closest_capsule

    # Return True if there are still capsules in the game and zero otherwise
    def check_capsules(self,state):
        length = len(state.getCapsules())
        if length > 0:
            return True
        else:
            return False

    def min_distance(self, pos1, pos2):
        # adjust to be (x,y) format
        pos1_adjusted = (math.ceil(pos1[1]),math.ceil(pos1[0]))
        pos2_adjusted = (math.ceil(pos2[1]),math.ceil(pos2[0]))
        shortest_path = nx.shortest_path(self.graph, pos1_adjusted, pos2_adjusted)
        return len(shortest_path) - 1

    def build_graph(self,state):
            walls = state.getWalls()
            width = state.data.layout.width
            height = state.data.layout.height
            self.graph = nx.grid_2d_graph(height, width)
            G2 = nx.grid_2d_graph(height, width)
            for node in G2.nodes():
                i = node[0]
                j = node[1]
                if (walls[j][i] == True):
                    self.graph.remove_node(node)

    def build_state(self, state, previous_built_state):
        if self.graph == None:
            # graph hasnt been built yet
            self.build_graph(state)
        agent_position = [state.getPacmanPosition(), previous_built_state['positions'][0]]
        valid_actions = self.valid_actions_vector(state)

        agent_direction = self.direction_to_int(state.getPacmanState().getDirection())
        actual_closest_ghost_pos, closest_ghost_scared_timer, there_are_ghosts = self.closest_ghost_pos_scared_time(state)
        closest_ghost_pos = [actual_closest_ghost_pos,previous_built_state['positions'][2]]
        closest_capsule_position = self.closest_capsule_position(state)
        there_are_capsules = self.check_capsules(state)
        closest_food_pos = self.closest_food(state)

        if (not(self.closest_ghost_is_nearby(state,closest_ghost_pos[0],2))) and (self.there_is_food_nearby(state,closest_food_pos,1)):
            ghost_away_food_nearby = True
        else:
            ghost_away_food_nearby = False

        #previous_agent_position = previous_built_state['agent_position']
        #previous_closest_ghost_pos = previous_built_state['previous_closest_ghost_pos']

        built_state = dict({
            'positions' : agent_position + closest_ghost_pos + [closest_capsule_position] + [closest_food_pos] + [(closest_ghost_scared_timer,0)],
            'booleans' : valid_actions + [there_are_ghosts] + [there_are_capsules] + [ghost_away_food_nearby]
        })

        return built_state

    def next_state(self, actual_state, action):
        valid_action = action
        if action not in actual_state.getLegalPacmanActions():
            valid_action = Directions.STOP
        next_game_state = actual_state.generatePacmanSuccessor(valid_action)
        return self.build_state(next_game_state, self.last_state)


    def reward_function(self, state, action):
        valid_action = action
        # Agent also gets a bad reward if it selected a non valid action
        if action not in state.getLegalPacmanActions():
            legal_action_reward = -5
            valid_action = Directions.STOP
        else:
            legal_action_reward = 0

        next_game_state = state.generatePacmanSuccessor(valid_action)

        # Scored obtained by action
        if next_game_state.getNumFood() < state.getNumFood():
            # ate one food
            score_gain = 1
        elif len(next_game_state.getCapsules()) < len(state.getCapsules()):
            # ate a capsule
            score_gain = 20
        else:
            # didn't eat anything
            score_gain = -1

        if (next_game_state.getNumAgents() < state.getNumAgents()):
            # ate a ghost
            eat_ghost_reward = 20
        else:
            eat_ghost_reward = 0

        # Reward also depends on winning or not the game
        if next_game_state.isWin():
            win_lose_reward = 100
        elif next_game_state.isLose():
            win_lose_reward = -100
        else:
            win_lose_reward = 0

        # Total reward is composed of the score gained, the win/lose state and wheter the action chosen is valid or not
        return score_gain + win_lose_reward + legal_action_reward + eat_ghost_reward

    # Return True if the action is going to finish the game and False otherwhise
    def is_terminal(self, state, action):
        valid_action = action
        if action not in state.getLegalPacmanActions():
            valid_action = Directions.STOP
        next_game_state = state.generatePacmanSuccessor(valid_action)
        return next_game_state.isWin() or next_game_state.isLose()

    def execute(self, actions, state):
        self.last_state = self.build_state(state,self.last_state)
        next_state = self.next_state(state,actions)
        terminal = self.is_terminal(state, actions)
        reward = self.reward_function(state,actions)
        return next_state, terminal, reward
