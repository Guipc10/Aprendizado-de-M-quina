from game import *
from pacman import *
from myEnv import CustomEnvironment,CustomEnvironment1, CustomEnvironment2, CustomEnvironment3, CustomEnvironment4, CustomEnvironment5, CustomEnvironment6
from tensorforce.environments import Environment
from tensorforce.agents import Agent
from myAgent import MyPacman
import matplotlib.pyplot as plt
from Agents import DumbAgent
import itertools

def createGame(newAgent, visualization, layout, pacman, ghosts, display, numGames, record, numTraining = 0, catchExceptions=False, timeout=30):
    rules = ClassicGameRules(timeout)
    import textDisplay
    if visualization == True:
        display = display
        rules.quiet = False
        beQuiet = False
    else:
        display = textDisplay.NullGraphics()
        rules.quiet = True
        beQuiet = True
    return rules.newGame(layout, newAgent, ghosts, display, beQuiet, catchExceptions)

def run_train(environment, agent, n_episodes, print_frequency, save_frequency, visualization, save_folder, args):
    mean_scores = []
    mean_episodes_n = []
    win_rate = []
    scores = []
    episodes_n = []
    episode = 0
    best_score = -600
    score_sum = 0
    win_n = 0
    for i in range(n_episodes):
        pacman = MyPacman(environment, agent)
        game = createGame(**args, newAgent = pacman, visualization = visualization)
        game.run()

        # if last terminal wasnt true, hard code one last episode so the agent knows the episode ended
        reward = 0
        if pacman.get_last_terminal() == False:
            last_state = pacman.get_state()

            agent.act(last_state)
            if game.state.isWin():
                reward = 100
                win_n += 1
            else:
                # lost
                reward = -100

            agent.observe(terminal = True, reward = reward)

        # sum to calculate de mean score and reward
        accumulated_reward = pacman.get_total_reward() + reward
        score_sum += game.state.getScore()
        scores.append(game.state.getScore())
        episodes_n.append(episode)
        # Save informations

        if (episode%print_frequency == 0):
            print(f'Game {i}, mean score = {score_sum/print_frequency}, mean total reward = {accumulated_reward/print_frequency},win rate = {win_n/print_frequency}')
            mean_scores.append(score_sum/print_frequency)
            mean_score = score_sum/print_frequency
            if mean_score > best_score:
                best_score = mean_score
            win_rate.append(win_n/print_frequency)
            mean_episodes_n.append(episode)
            win_n = 0
            score_sum = 0
            accumulated_reward = 0

        if (episode%save_frequency == 0):
            fig,ax1 = plt.subplots()
            lns1 = ax1.plot(episodes_n, scores, label = 'episode score', color = 'green')
            lns2 = ax1.plot(mean_episodes_n, mean_scores, label = f'mean score {print_frequency} episodes', color = 'blue')
            ax1.set_xlabel('training episode')
            ax1.set_ylabel('score')

            ax2 = ax1.twinx()
            lns3 = ax2.plot(mean_episodes_n, win_rate, label = f'win rate {print_frequency} episodes', color = 'red')
            ax2.set_ylabel('win rate')

            lns = lns1+lns2+lns3
            labs = [l.get_label() for l in lns]
            ax1.legend(lns, labs, loc=0)

            fig.tight_layout()
            fig.savefig(os.getcwd()+'/'+save_folder+'/episode'+str(episode))
            agent.save(directory = os.getcwd()+'/'+save_folder+'/', format = 'checkpoint', append = 'episodes')

        episode += 1
    return best_score

# Inspired by this article: https://towardsdatascience.com/ai-learns-to-fly-part-2-create-your-custom-rl-environment-and-train-an-agent-b56bbd334c76
def parameters_search_dqn(environment, param_grid_list, n_episodes, args):
    lists = param_grid_list.values()
    param_combinations = list(itertools.product(*lists))
    total_param_combinations = len(param_combinations)
    print("Number of combinations", total_param_combinations)

    # Initialize lists to gather the results over the different combinations
    scores = []
    names = []
    scores_vec = {}

    for i, params in enumerate(param_combinations):
        print("Combination", i, "/", total_param_combinations)
        # Fill the parameters dictionnary with the current parameters combination
        param_grid = {}
        for param_index, param_name in enumerate(param_grid_list):
            param_grid[param_name] = params[param_index]
        print('model:',str(param_grid))
        agent = Agent.create(
                agent='dqn', environment=environment,
                # Automatically configured network
                network=dict(type = param_grid['network_type'],
                size = param_grid['size'],
                depth = param_grid['depth']),
                memory = param_grid['memory'],
                # Optimization
                batch_size=param_grid['batch_size'],
                update_frequency=param_grid['update_frequency'],
                learning_rate=param_grid['learning_rate'],
                discount=param_grid['discount'],
                predict_terminal_values=param_grid['predict_terminal_values'],
                exploration=param_grid['exploration'],
                variable_noise=param_grid['variable_noise']
            )

        best_score = run_train(environment, agent, n_episodes, 50, 500, visualization = False, save_folder = 'savings0'+str(i), args = args)
        print('-------------------------------------------')
        print('best mean score: ', best_score)
        print('model:',str(param_grid))
        print('-------------------------------------------')
        scores.append(best_score)
        names.append(str(param_grid))
        agent.close()

    # Create a dictionnary of hyperparameters and their results
    dict_scores = dict(zip(names, scores))
    best_model = max(dict_scores, key=dict_scores.get)
    print('best model:', best_model, 'best mean score:', dict_scores[best_model])

if __name__ == '__main__':
    args = readCommand("-l originalClassic".split())

    #first runs with a dumb agent so the environment can have access to the initial state easily
    dumb_agent = DumbAgent()
    game = createGame(**args, newAgent = dumb_agent, visualization = False)
    game.run()
    initial_state = dumb_agent.get_initial_state()

    #instantiate the environment
    environment = CustomEnvironment5(initial_state)

    # param_grid_list = {}
    # param_grid_list["DQN"] = {
    #     "batch_size": [10],
    #     "update_frequency": [1],
    #     "learning_rate": [dict(type='linear', unit='episodes', num_steps=2000,initial_value=0.1, final_value=0.0005)],
    #     'memory': [1000],
    #     "discount": [0.95],
    #     "predict_terminal_values": [True],
    #     "exploration": [dict(type = 'linear', unit = 'episodes', num_steps = 2000, initial_value = 0.9, final_value = 0.005)],
    #     "variable_noise": [0.1,0.5,1],
    #     'l2_regularization ': [0.1],
    #     "network_type": ['auto'],
    #     'size': [16,32],
    #     'depth' : [2,4,6,8]
    # }aaa
    # #
    # parameters_search_dqn(environment, param_grid_list['DQN'], 4005, args)
    agent = Agent.create(
            agent='dqn', environment=environment,
            # Automatically configured network
            network= dict(type = 'custom',
                        layers = [ [
                dict(type='retrieve', aggregation='stack', tensors=['walls', 'foods', 'capsules', 'pacman', 'last_pacman', 'active_ghosts', 'last_active_ghosts', 'scared_ghosts', 'last_scared_ghosts']),
                dict(type='conv2d', size=10, window = 2, activation = 'relu'),
                dict(type='conv2d', size=10, window = 2, activation = 'relu'),
                dict(type='conv2d', size=10, window = 2, activation = 'relu'),
                dict(type = 'flatten'),
                dict(type='dense', size=10, activation = 'relu'),
                dict(type='dense', size=5, activation = 'softmax')
            ] ]
                        ),
            memory = 100000,
            # Optimization
            batch_size=10,
            predict_terminal_values = True,
            learning_rate=0.001,
            discount=0.95,
            l2_regularization = 0.1,
            # Preprocessing

            # Exploration
            #exploration = 0.01,
            exploration=dict(type = 'linear', unit = 'episodes', num_steps = 500, initial_value = 0.9, final_value = 0.01),
            variable_noise=0.01
       )

    print(agent.get_architecture())
    print(agent.get_specification())

    run_train(environment, agent, 1005, 50, 500, visualization = False, save_folder = 'original_conv', args = args)
    agent.close()
    environment.close()
