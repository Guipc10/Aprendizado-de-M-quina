from game import Agent
from game import Directions
from game import *
from pacman import *

class MyPacman(Agent):

    def __init__(self, environment, learner_agent, index = 0):
        super().__init__(index)
        self.environment = environment
        self.learner_agent = learner_agent
        self.built_state = self.environment.reset()
        self.num_updates = 0
        self.total_reward = 0
        self.last_terminal = False

    def getAction(self,state):
        self.built_state = self.environment.build_state(state, self.built_state)
        action = self.learner_agent.act(self.built_state)
        game_action = self.number_to_action(action)
        states, terminal, reward = self.environment.execute(actions=game_action, state = state)
        self.last_terminal = terminal
        self.total_reward += reward
        self.num_updates += self.learner_agent.observe(terminal=terminal, reward=reward)

        if game_action not in state.getLegalPacmanActions():
            game_action = Directions.STOP

        return game_action

    def number_to_action(self, action_number):
        if action_number == 0:
            action = Directions.NORTH
        elif action_number == 1:
            action = Directions.SOUTH
        elif action_number == 2:
            action = Directions.EAST
        elif action_number == 3:
            action = Directions.WEST
        elif action_number == 4:
            action = Directions.STOP

        return action

    def get_state(self):
        return self.built_state

    def get_total_reward(self):
        return self.total_reward

    def get_last_terminal(self):
        return self.last_terminal
